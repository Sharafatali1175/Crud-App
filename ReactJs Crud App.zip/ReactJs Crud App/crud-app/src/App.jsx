
import { Post } from "./Components/Post"
import  "./App.css"

const App = () => {
   
  return (
    <>  
    <section className="main-section">
       <Post/>
    </section> 
    </>
  )
}

export default App
